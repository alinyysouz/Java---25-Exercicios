package javaExercicios;

import java.util.Scanner;

public class exer21 {

	public static void main(String[] args) {
		// 21- A Loja Mam�o com A��car est� vendendo seus produtos em 5 (cinco) presta��es sem juros. Fa�a um programa que receba um valor de uma compra e mostre o valor das presta��es.
		
		Scanner teclado = new Scanner(System.in);

   
        System.out.print("Digite o valor total da compra: ");
        double valorCompra = teclado.nextDouble();

        
        double valorPrestacao = valorCompra / 5;

       
        System.out.println("O valor de cada presta��o �: R$ " + valorPrestacao);

        teclado.close();
		
		
		

	}

}
