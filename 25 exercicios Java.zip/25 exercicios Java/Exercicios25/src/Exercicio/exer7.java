package Exercicio;

public class Ex07 {

	public static void main(String[] args) {
		double media1 = (89 + 7) / 2.0;
        double media2 = (4 + 5 + 6) / 3.0;
        double somaMedias = media1 + media2;
        double mediaDasMedias = somaMedias / 2.0;

        System.out.println("M�dia de 89 e 7: " + media1);
        System.out.println("M�dia de 4, 5 e 6: " + media2);
        System.out.println("Soma das m�dias: " + somaMedias);
        System.out.println("M�dia das m�dias: " + mediaDasMedias);

	}

}
