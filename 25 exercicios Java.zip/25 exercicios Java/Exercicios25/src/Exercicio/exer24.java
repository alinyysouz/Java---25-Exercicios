package javaExercicios;

import java.util.Scanner;

public class exer24 {

	public static void main(String[] args) {
		// 24- Escreva um programa que leia uma sequ�ncia de n�meros do usu�rio e realize a soma desses n�meros. Encerre a execu��o quando um n�mero negativo for digitado.
		
		 Scanner teclado = new Scanner(System.in);

	        int soma = 0;
	        int n;

	        System.out.println("Digite uma sequ�ncia de n�meros (digite um n�mero negativo para encerrar):");

	        
	        while (true) {
	            System.out.print("Digite um n�mero: ");
	            n = teclado.nextInt();

	           
	            if (n < 0) {
	                break;
	            }

	            
	            soma += n;
	        }

	      
	        System.out.println("A soma dos n�meros �: " + soma);

	        teclado.close();

	}

}
