package Exercicio;
import java.util.Scanner;

public class Ex12 {

	public static void main(String[] args) {
		 int soma = 0;
	        for (int i = 1; i <= 15; i++) {
	            soma += i;
	        }
	        System.out.println("A soma dos n�meros de 1 a 15 �: " + soma);

	}

}
