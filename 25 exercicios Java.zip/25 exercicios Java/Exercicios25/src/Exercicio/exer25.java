package javaExercicios;

import java.util.Scanner;

public class exer25 {

	public static void main(String[] args) {
		// 25 - Escreva um algoritmo que leia uma sequ�ncia de n�meros do usu�rio e realize e a soma desses n�meros. Encerre a execu��o quando um n�mero negativo for digitado.
		
		 Scanner teclado = new Scanner(System.in);

	        int soma = 0;
	        int num;

	        System.out.println("Digite uma sequ�ncia de n�meros (digite um n�mero negativo para encerrar):");

	    
	        do {
	            System.out.print("Digite um n�mero: ");
	            num = teclado.nextInt();

	            
	            if (num >= 0) {
	                soma += num; 
	            }
	        } while (num >= 0);

	        
	        System.out.println("A soma dos n�meros �: " + soma);

	        teclado.close();
		

	}

}
