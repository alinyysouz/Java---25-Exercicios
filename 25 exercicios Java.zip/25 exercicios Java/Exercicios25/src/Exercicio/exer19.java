package javaExercicios;

import java.util.Scanner;

public class exer19 {

	public static void main(String[] args) {
		// 19- Elaborar um programa que efetue a apresenta��o do valor da convers�o em real (R$) de um valor lido em d�lar (US$). O programa dever� solicitar o valor da cota��o do d�lar e tamb�m a quantidade de d�lares dispon�veis com o usu�rio.

		
		Scanner teclado = new Scanner(System.in);


        System.out.print("Digite a cota��o do d�lar (em reais): ");
        double cotacaoDolar = teclado.nextDouble();

 
        System.out.print("Digite a quantidade de d�lares a ser convertida: ");
        double quantidadeDolares = teclado.nextDouble();

      
        double valorEmReais = quantidadeDolares * cotacaoDolar;

    
        System.out.println("O valor de " + quantidadeDolares + " d�lares � equivalente a R$" + valorEmReais + " reais.");

        teclado.close();
	}

}
